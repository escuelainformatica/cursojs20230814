<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;

class ProductoController extends Controller
{
    public function list() {
        sleep(2);
        return Producto::all();
    }
    public function get($id) {
        return Producto::find($id);
    }
    public function insert(Request $req) {
        $prod=$req->all();
        $producto=new Producto($prod);
        return $producto->save();
    }
    public function update(Request $req) {
        $prod=$req->all();
        $productoOld=Producto::find(@$prod['id']);
        if(!$productoOld) {
            return false;
        }
        $productoOld->name=$prod['name'];
        $productoOld->description=$prod['description'];
        $productoOld->price=$prod['price'];
        $productoOld->quantity=$prod['quantity'];
        return $productoOld->save();
    }
    public function delete($id) {
        $prod=Producto::find($id);
        if($prod===null) {
            return false;
        }
        return $prod->delete();
    }
}
